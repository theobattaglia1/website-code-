# CPC - Spotlight/Highlight (TMNT) 🐢

A Pen created on CodePen.io. Original URL: [https://codepen.io/Theo-Battaglia/pen/WNPxOoJ](https://codepen.io/Theo-Battaglia/pen/WNPxOoJ).

A throw back to old Teenage Mutant Ninja Turtle games of the 90's. 

This character select screen allows for multiple input types and is completely responsive to smaller screens.